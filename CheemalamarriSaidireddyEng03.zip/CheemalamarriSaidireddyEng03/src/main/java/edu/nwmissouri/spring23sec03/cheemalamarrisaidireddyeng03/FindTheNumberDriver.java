/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.nwmissouri.spring23sec03.cheemalamarrisaidireddyeng03;

import java.util.Random;

/**
 *
 * @author Saidi Reddy Cheemalamarri
 */
public class FindTheNumberDriver {
    public static void main(String[] args) {
        int seed=558642;
        int numberToFind=5;
        int counter=1;
        //create an object reference to class random
        Random rand=new Random();
        System.out.println("Actual number to find is "+numberToFind);
        while(seed!=numberToFind){
            //generating a random number
            int randomNumber=rand.nextInt(10);
            System.out.println("Random Number "+counter+" :"+randomNumber);
            counter+=1;
            seed=randomNumber;
            
        }
        System.out.println("Number of counts to find the actual number 5 for s558642 is : "+(counter-1));
    }
    
}
